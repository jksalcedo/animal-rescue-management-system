package polymorphism;

public interface ISchedule {
    void perform();

    String getDescription();
}
