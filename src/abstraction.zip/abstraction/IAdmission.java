package abstraction;

public interface IAdmission {
    void admit();

    String getAdmissionDetails();
}
